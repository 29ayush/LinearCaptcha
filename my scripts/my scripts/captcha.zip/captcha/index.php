<html>
<h1 style=color:red;size:100px><U><i><marquee><center>Ul2 All in 1 Earning By ~~Bindass Khiladi~~</center></marquee></i></U></h1>
<h2 
style=color:brown;size:50px><center>DON'T SHARE THE SITE ENJOY EARNING 
</center>
</h2>
<center>
<form action="captcha.php" method="post">
<body style="background-color:white;">
<br/>
<body><centre><font color=orange><a href="jpup.php">Update Jackpot</a></font>
<fieldset data-role="controlgroup">
<div class="info"><label for="text"><font color=blue>Username</font></label>
<input type="text" id="username" name="username" placeholder="" value="" type="text" /></div>
</fieldset>
<br><fieldset data-role="controlgroup">
<div class="info"><label for="password"><font color=blue>Password:</font></label>

<input type="password" id="password" name="password" placeholder="" value="" type="password" /></div>
</fieldset>
<br><fieldset data-role="controlgroup">
<div class="info"><label for="text"><font color=blue>Proxy:Port</font></label>
<input type="text" id="Proxy" name="proxy" placeholder="" value="" type="numbers" /></div>

 <br>
 <input type=submit name=submit value=StartEarn>



