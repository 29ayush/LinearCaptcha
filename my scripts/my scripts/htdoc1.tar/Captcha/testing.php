<?php
require 'ultoogamefunctions.php';
$content = file_get_contents('log2.txt');
echo getlearnandearndata($content);

?>