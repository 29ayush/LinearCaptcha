<?php


function getlearnandearndata($content)
             {
                    $elval = getelval($content);
                    preg_match('/<input type=\"hidden\" name=\"xdfrc\" value=\"(.*?)\"/i',$content,$matches);
                    $xdfrc = $matches[1];
                    preg_match('/<input type=\"hidden\" name=\"qwweeq\" value=\"(.*)\"/i',$content,$matches);
                    $ans= urlencode($matches[1]);
                    $ans=str_replace("%20","+",$ans);
                    preg_match('/<input type=\"hidden\" name=\"poedxd\" value=\"(.*)\"/i',$content,$matches);
                    $ansdet = urlencode($matches[1]);
                    $ansdet=str_replace("%20","+",$ansdet);
                    $data = "visited=poiuwrdcxzajmkiytdgdjdfb&opt[]=$ans&$elval&xdfrc=$xdfrc&qwweeq=$ans&poedxd=$ansdet&button=Submit";
                    $data = str_replace("\n","",$data);
                    return $data;
             }








    function getelval($html)
             {

                 	preg_match("/el.name='(.*)'/i", $html, $matches);
                 	$name = $matches[1];
                	preg_match("/process\('(.*)'/i", $html, $matches);
                        $val=$matches[1];
          
                        preg_match_all("/val = val\.(.*)\((.*)\)/i", $html, $matches);
                        $count = count($matches[1]);
            
                        for($i=0; $i<$count;$i++)
                                      {
          
                                             $func=$matches[1][$i];       
                                             $index = $matches[2][$i];
                                             $index = explode(',', $index);
                                             if ($index[1] == "") $index[1] = strlen($val);
                                             if($index[0]<0) $index[0] = strlen($val) + $index[0] + 1;
                                             if($index[1]<0) $index[1] = strlen($val) + $index[1];
                                             
                                             if ($func == "substring" || $func == "slice") $val = substr($val, $index[0], $index[1] - $index[0]);
                                             elseif ($func == "substr") $val = substr($val, $index[0], $index[1]);
                                             elseif ($func == "charAt") $val = $val[$index[0]];
                                             elseif ($func == "toLowerCase") $val = strtolower($val);
                                             elseif ($func == "toUpperCase") $val = strtoupper($val);
         
                                        }

                          return $name."=".$val;


                  }
?>
