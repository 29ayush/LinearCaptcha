<?php

$url = "http://ultoo.com";
$secure = "$url/secure.php";
$learnstart= "$url/learnenglish.php";
$learnques= "$url/learnenglishques.php";
$learnmid="$url/englishresponse.php";

$agent = "Opera/9.80 (J2ME/MIDP; Opera Mini/4.5.33634/32.1440; U; en) Presto/2.8.119 Version/11.10";
$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
$headers[] = 'Connection: Keep-Alive';
$headers[] = 'Content-type: application/x-www-form-urlencoded;charset=UTF-8';
$headers[] = 'Accept-Language: en-us,en;q=0.8';
$headers[] = 'Accept-Encoding gzip,deflate';
$headers[] = 'Keep-Alive: 300';
$headers[] = 'Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7';
$headers[] = 'Cache-Control: max-age=0';

require 'ultoogamefunctions.php';

$proxy = $_REQUEST['proxy'];
$captr = $_REQUEST['captr'];
$cookie = $_REQUEST['cookie'];

$username = trim($_REQUEST['username']);

$cap = $_REQUEST['cap'];

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, $secure);

curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$cap_data = $captr . "=nlp&captcha=$cap";
curl_setopt($ch, CURLOPT_POSTFIELDS, $cap_data);
$html = curl_exec($ch);



if (stristr($html, "box do not match"))
	{
	die("<h3><tt><font color=red>------------ You Have Entered Wrong Captcha. --------</font></h3>");
	}

if (stristr($html, "mywallet"))
	{
	echo "<h2><tt><font color=green>Ho gaya Login...Earning start !!</tt></h4><br />";
	flush();
	ob_flush();
	sleep(3);
	}
  else
	{
	echo "<h3><tt><font color=red>-------- Some Error Occured. ----</font></h3></tt>";
	$loogc++;
	flush();
	ob_flush();
	if ($loogc > 6) exit;
	}

curl_setopt($ch, CURLOPT_URL, $learnstart);
curl_setopt($ch, CURLOPT_POST, 0);
curl_setopt($ch, CURLOPT_REFERER, $learnstart);
$html = curl_exec($ch);

for($i=0;$i<10;$i++)
{
flush();
ob_flush();
curl_setopt($ch, CURLOPT_URL, $learnques);
curl_setopt($ch, CURLOPT_REFERER, $learnstart);
$queshtml = curl_exec($ch);


$data = getlearnandearndata($html);
echo $data;

curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_REFERER, $learnques);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
$submithtml = curl_exec($ch);

curl_setopt($ch, CURLOPT_URL, $learnmid);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
$resposehtml = curl_exec($ch);


$qno = $i+1;
if(stristr($responsehtml,"Wow!! That's the correct answer."))
{
echo "<font color=seagreen>| $qno. </font><font color=Crimson>Correct Answer|</font><font color=white>,</font>";
flush();
ob_flush();
}
else
{
file_put_contents("error1$i.txt",$queshtml);
file_put_contents("error2$i.txt",$submithtml);
file_put_contents("error3$i.txt",$responsehtml);
die("|".$qno."error|");
flush();
ob_flush();
}
}
echo "<br/>$cookie<br/>";
echo "Learn And Earn Complete, Go Check Your Earnings";
?>