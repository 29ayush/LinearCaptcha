<font face="Trebuchet MS"><html>
<align="center"><head>
<center><title>Ultoo Full Earning</title>

<br/>
<link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
<align="center"><div class='header'>Ultoo Full Earning </div>

<div class='title'><center> <a href="https://www.facebook.com/alltechinonefree" target="_blank" title="Like Our Facebook Page">Like Our Facebook page !!</a></center></div>
<div class="title2"> Enter Login Details </div>
<div class="mainbox"><center><br><font color=green><font size=3pt>PLAY ALL(QUIZ+POLL+JACKPOT+BAL CHECKER)</font></center></div>

<p align="center"><b style="color:"><script src="http://greentooth.xtgem.com/j/time.js"></script></b></p> 

<center>
<form action="captcha.php" method="post">

Username :<br> <input type="text" name="username"><br>
Password :<br> <input type="text" name="password"><br>
Proxy:Port<br> <input type="text" name="proxy" placeholder="" value="" type="numbers"<br>
<br>
 <input type=submit name=submit value=StartEarn>
</form>


<center>
<centre><li><font color=green><a href="jp.php"> JP update </a> </font>
<centre><li><font color=green><a href="proxy.php"> Proxy Update </a> </font>
<centre><li><font color=green><a href="delete.php"> Delete Images </a> </font>
<center><li><font color=green><a href="80.php"> Proxy Finder [port 80] </a> </font></center>
<centre><li><font color=green><a href="8080.php"> Proxy Finder [port 8080] </a> </font>
<centre><li><font color=green><a href="3128.php"> Proxy Finder [port 3128] </a> </font>
<centre><li><font color=green><a href="8123.php"> Proxy Finder [port 8123] </a> </font>



</div>

<br/>
<div id="footer_bg">
<div class="footer" align="center">&copy; <a href="http://www.alltechinone.com/" target="_blank" title="Visit Our Site">All Tech In One</a></div>
</html>