
<title>Laptu Earner </title><div style="background: green; padding:4px; color:white" align="center"><font size=5pt><font/></div>
<font color=red>Laptu Earner</font>

<p align="center"><b style="color:"><script src="http://greentooth.xtgem.com/j/time.js"></script></b></p> 
<?php
include_once("mathocr.php");
include_once("funocr.php");
@ini_set('zlib.output_compression',0);
@ini_set('implicit_flush',1);
@ob_end_clean();
set_time_limit(0);
ob_implicit_flush(1);
ob_start();

echo '<html>
<head>
</head>
<title>BINDASS KHILADI</title>
<div align=center>
<div class="mainbox"><center><br><font color=gray><font size=9pt>BINDASS KHILADI</font></center></div><br/><br/><br/><font size=3>';

flush();
ob_flush(); 

$proxy = $_REQUEST["proxy"];
$uid = $_REQUEST["uid"];
$pwd = $_REQUEST["pwd"];
$c = $_REQUEST["c"];
$cn = str_replace(".","",$_SERVER['REMOTE_ADDR']);
$cookie = "coki/".$cn.".txt";
$agent = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.7 (KHTML, like Gecko) Chrome/26.0.912.36 Safari/535.7";

$ch = curl_init();
$dataa = "secure_code=$c&submit=Login";

curl_setopt($ch, CURLOPT_URL,"http://u.laaptu.com/captvalidate.action");
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);

curl_setopt($ch, CURLOPT_COOKIESESSION, false);
curl_setopt($ch, CURLOPT_POST, 1);

curl_setopt($ch, CURLOPT_POSTFIELDS,$dataa);
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

curl_setopt($ch, CURLOPT_REFERER, "http://u.laaptu.com/loginAgain.action");
$html=curl_exec($ch);

if(!stristr($html,"homepage.action"))
{
echo "<hr><font color=red><b>Invalid Captcha. Try Again</b></font><hr></div>";
$img = $_REQUEST["img"];
if($img)
{
unlink($img);
}
if($cookie)
{
unlink($cookie);
}
die();
}

preg_match("/id=(.*?)\n/",$html,$id);
$id = $id[1];
$id = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/","", $id);
$id = preg_replace('/\s+/', ' ', trim($id));
$id = preg_replace('~[\r\n]+~', '', $id);
$id = preg_replace("/[\\n\\r]+/", "", $id);

#region Initial Balance Check
$ch = curl_init();/*
$dataa = "hToken=$id";
curl_setopt($ch, CURLOPT_URL,"http://u.laaptu.com/homepage.action?id=$id");

curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);

curl_setopt($ch,CURLOPT_COOKIEJAR,$cookie);
curl_setopt($ch, CURLOPT_POST, 1);

curl_setopt($ch, CURLOPT_POSTFIELDS,$dataa);

curl_setopt($ch,CURLOPT_AUTOREFERER,1);curl_setopt($ch,CURLOPT_HEADER,1);curl_setopt($ch,CURLOPT_VERBOSE,1);

curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

curl_setopt($ch, CURLOPT_REFERER, "http://u.laaptu.com/homepage.action?id=$id");
$html=curl_exec($ch);
preg_match("#<span class=\"walletdig\">(.*?)</span>#",$html,$ter);
$ter = $ter[1];

$dataa = "hToken=$id";

curl_setopt($ch, CURLOPT_URL,"http://u.laaptu.com/settings.action?id=$id");

curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch,CURLOPT_COOKIEJAR,$cookie);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,$dataa);

curl_setopt($ch,CURLOPT_AUTOREFERER,1);curl_setopt($ch,CURLOPT_HEADER,1);curl_setopt($ch,CURLOPT_VERBOSE,1);

curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

curl_setopt($ch, CURLOPT_REFERER, "http://u.laaptu.com/homepage.action?id=$id");
$html=curl_exec($ch);
preg_match("#<input name=\"newemail\" id=\"btnEmail1\" type=\"text\" value=\"(.*?)\" class=\"bdr3 input\" />#",$html,$name);
$name=$name[1];

echo"<font color=pink size=4>USER ID </font><br><br>";
echo "<div class=content2><font color=orange><b> $name</font><font color=GREEN> Balance: </font><u><font color=#CCEEFF>".$ter."</u></b></font><br></div>";
#end region

flush();
ob_flush(); 
#region First Quiz
*/
again:
$url="http://u.laaptu.com/mathquiz.action?id=$id";
$salamon=0;
$ftime=1;
$ref="http://u.laaptu.com/homepage.action?id=$id";
quizA:
$salamon++;

//$dataa = "hToken=$id";

curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_USERAGENT, $agent);

curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch,CURLOPT_COOKIEJAR,$cookie);

curl_setopt($ch, CURLOPT_POST, 0);
//curl_setopt($ch, CURLOPT_POSTFIELDS,$dataa);
curl_setopt($ch,CURLOPT_AUTOREFERER,1);curl_setopt($ch,CURLOPT_HEADER,1);curl_setopt($ch,CURLOPT_VERBOSE,1);

curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_REFERER, $ref);
$html=curl_exec($ch);
//preg_match_all('#<img id="optionansimg"(.*?)src=\"(.*?)\" />#',$html, $images);
preg_match_all('#src="(?=data:image)(.*?)" />#',$html,$images);

$ans1=$images[1][0];
preg_match_all("#<input type=\"hidden\" name=\"hidQNO\" id=\"hidQNO\" value=\"(.*?)\">#",$html,$qNo);
$cques=$qNo[1][0];


if(stristr($html,"Today's Math quiz is over"))
{
preg_match("#Total Questions Played &nbsp;&nbsp;&nbsp;&nbsp; <span>(.*?)</span>#",$html,$amt);
$amt1=$amt[1];
preg_match("#Amt Credited in your wallet <span> (.*?)</span>#",$html,$amt);
$amt2=$amt[1];
echo "<font color=magenta><b><br>Math quiz over <br><br>QUIZ SUBMITTED: $amt1 <br> Amt Credited:$amt2<br></b></font>";
flush();
                ob_flush(); 
                goto quizBB;
}
if($salamon>8)
{
$salamon=0;
$cque=$cques-1;
echo "<font color=red><b><br>$cque question completed of MATH quiz<br></b></font>";
                flush();
ob_flush(); 
goto quizBB;
}

$d1=math_ocr_call($ans1,$cques); 
$cns=0;
post1:
switch($cns)
{
    case 0: $da=$d1[0][0];
        break;
    case 1: $da=$d1[0][1];
        break;
    case 2: $da=$d1[0][2];
        break;
    case 3: $da=$d1[0][3];
    break;
case 4: $da=$d1[0][4];
    break;
default:
goto again;
}
if($ftime==1)
{
$dataa = "hToken=$id&hCat=1&selAnswer=0&hidQNO=$cques&quizAnswer=$da";
$ftime=0;
}
else
{
$dataa = "hToken=$id&hCat=1&selAnswer=0&hidQNO=$cques&quizAnswer=$da&jsonpid=".$pid[1];
}
//echo $dataa."<br>";
$ref=$url;

curl_setopt($ch, CURLOPT_URL,"http://u.laaptu.com/checkAnswerMath.action");
curl_setopt($ch, CURLOPT_USERAGENT, $agent);

curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch,CURLOPT_COOKIEJAR,$cookie);
curl_setopt($ch, CURLOPT_POST, 1);

curl_setopt($ch, CURLOPT_POSTFIELDS,$dataa);
curl_setopt($ch,CURLOPT_AUTOREFERER,1);
curl_setopt($ch,CURLOPT_HEADER,1);

curl_setopt($ch,CURLOPT_VERBOSE,1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_REFERER, $url);

$html=curl_exec($ch);
$url = curl_getinfo($ch , CURLINFO_EFFECTIVE_URL);

preg_match("#pid=(.*?)&id=[\s\w.]*#",$url,$pid);

$cns++;
if(stristr($html,"That's not the answer"))
{
goto post1;
}
else if(stristr($html,"from the given options"))
{
echo "<font color=white><br>NOT ABLE TO IDENTIFY $d1[1]";
goto again;
//imagepng($im,"img/i/math-$name-$cques-".$da.".png");
}
else
{
preg_match_all("#<div class=\"ruptext\">(.*?)</div>#",$html,$bal);
$rs=$bal[1][0];
$ps=$bal[1][1];
echo "<i><b><font color=orange>Q[<font color=orange>$cques</font>]. Success : Bal<font color=blue>=Rs $rs.$ps ||  </font> Ans: [<font color=blue>$da</font>]</font><font color=navy><i>; </b>";
ob_flush();
        flush();
unlink($d1[1]);
if($cques<=30)
{
//echo "going to again<br>".$dataa."<br>";
goto again;
}
}

//for loop ends here

#end region
#region second

quizBB:
qagain:
$url="http://u.laaptu.com/quiz.action?id=$id";
$salamon=0;
$ftime=1;
$ref="http://u.laaptu.com/homepage.action?id=$id";
quizB:
$salamon++;

//$dataa = "hToken=$id";
curl_setopt($ch, CURLOPT_URL,$url);

curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch,CURLOPT_COOKIEJAR,$cookie);
curl_setopt($ch, CURLOPT_POST, 0);
//curl_setopt($ch, CURLOPT_POSTFIELDS,$dataa);
curl_setopt($ch,CURLOPT_AUTOREFERER,1);
curl_setopt($ch,CURLOPT_HEADER,1);
curl_setopt($ch,CURLOPT_VERBOSE,1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_REFERER, $ref);
$html=curl_exec($ch);
preg_match_all('#src="(?=data:image)(.*?)"[\s]*/>#',$html, $images);


$ans1=$images[1][1];

preg_match_all("#<input type=\"hidden\" name=\"hidQNO\" id=\"hidQNO\" value=\"(.*?)\">#",$html,$qNo);
$cques=$qNo[1][0];
//echo "<font color=white>".$cques;

if(stristr($html,"Today's FUN quiz is over"))
{
preg_match("#Total Questions Played &nbsp;&nbsp;&nbsp;&nbsp; <span>(.*?)</span>#",$html,$amt);
$amt1=$amt[1];
preg_match("#Amt Credited in your wallet <span> (.*?)</span>#",$html,$amt);
$amt2=$amt[1];
echo "<font color=magenta><b><br>FUN quiz over <br><br>QUIZ SUBMITTED: $amt1 <br> Amt Credited:$amt2<br></b></font>";
flush();
                ob_flush(); 
                goto sms;
}
if($salamon>8)
{
$salamon=0;
$cque=$cques-1;
echo "<font color=red><b><br>$cque question completed of fun quiz<br></b></font>";
                flush();
ob_flush(); 
goto sms;
}

list($d1,$img)=fun_ocr_call($ans1,$cques); 

$cns=0;
post1b:
switch($cns)
{
    case 0: $da=$d1[0];
$dmg=$img1[0];
        break;
    case 1: $da=$d1[1];
//$dmg=$img1[1];
        break;
    case 2: $da=$d1[2];
//$dmg=$img1[2];
        break;
    case 3: $da=$d1[3];
//$dmg=$img1[3];
    break;
case 4: $da=$d1[4];
//$dmg=$img1[4];
    break;
default:
goto qagain;
}

$da=urlencode($da);
abc: 
if($ftime==1)
{
$dataa = "hToken=$id&hCat=1&selAnswer=0&hidQNO=$cques&quizAnswer=$da";
$ftime=0;
}
else
{
$dataa = "hToken=$id&hCat=1&selAnswer=0&hidQNO=$cques&quizAnswer=$da&jsonpid=".$pid[1];
}
//echo "<font color=white>".$dataa."<br>";
ob_flush();
        flush();
$ref=$url;
curl_setopt($ch, CURLOPT_URL,"http://u.laaptu.com/checkAnswer.action");

curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch,CURLOPT_COOKIEJAR,$cookie);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,$dataa);
curl_setopt($ch,CURLOPT_AUTOREFERER,1);
curl_setopt($ch,CURLOPT_HEADER,1);
curl_setopt($ch,CURLOPT_VERBOSE,1);

curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_REFERER, $url);
$html=curl_exec($ch);
$url = curl_getinfo($ch , CURLINFO_EFFECTIVE_URL);

preg_match("#pid=(.*?)&id=[\s\w.]*#",$url,$pid);

$cns++;
if(stristr($html,"That's not the answer"))
{
//echo "<font color=white><br>wrong answer</br>";
ob_flush();
        flush();
goto post1b;
}
else if(stristr($html,"from the given options"))
{
//echo "<font color=white><br>NOT ABLE TO IDENIFY</font></br>";
if($ans1=="")
{
goto qagain;
}
else
{
echo $da." ".$img;
echo "<font color=white><br>NOT ABLE TO IDENTIFY.</br>";
//$st="<a href=http://162.243.229.247/kur/lap2/trainer_2.php?file=$dmg>$dmg</a>-{".$da."<=>".$answer."}";
//echo $st;
ob_flush();
    flush();
/*
$ch = curl_init();

curl_setopt($ch, CURLOPT_URL,"http://www.i2ocr.com/");
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch,CURLOPT_AUTOREFERER,1);
curl_setopt($ch,CURLOPT_HEADER,1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$html=curl_exec($ch);
preg_match('/PHPSESSID=(.*?);/', $html, $matches);
$cook=$matches[1].';';

$dataa = "i2ocr_options=url&i2ocr_uploadedfile=&i2ocr_url=http://162.243.229.247/kur/lap2/".$dmg."&i2ocr_languages=gb,eng";

curl_setopt($ch, CURLOPT_URL,"http://www.i2ocr.com/process_form");
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch, CURLOPT_COOKIE, $cook);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,$dataa);
curl_setopt($ch,CURLOPT_AUTOREFERER,1);
curl_setopt($ch,CURLOPT_HEADER,1);

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_REFERER, "http://www.i2ocr.com/");
$html=curl_exec($ch);
preg_match('#val\("(.*?)"\)#', $html, $matches);
//echo "<br>";
//var_dump($matches);
$answer=str_replace("\\n","",$matches[1]);
$st="<a href=http://162.243.229.247/lap2/$dmg>$dmg</a>-{".$da."<=>".$answer."}";
echo $st;
$da=$answer;
goto abc;*/
//echo $da." ".$im;
//echo '<a href="http://5.231.80.41/lap2uu/ques/"'.$im.' target="_blank">please click here to see image and fill in text box</a>';
/*
<img src="<?php echo $im; ?>"/><br>
<form method=post>
<input type="text" name="inp" value="<?php echo $da; ?>">
<input type="submit">
</form>
$da=$_REQUEST['inp'];
echo $da;*/
//imagepng($im,"img/i/math-$name-$cques-".$da.".png");
//$dc=$da;
goto qagain;
}
}
else
{
$themd5=md5($images[1][0]); 
if(!stristr(file_get_contents('db.txt'),"".$themd5.""))
{
$write="$themd5:$da;".PHP_EOL;
$filehandle = fopen("db.txt", 'a');
fwrite($filehandle, $write);
fclose($filehandle);
}
else
{
echo '<font color=white><i>,,,,labh gya oye :D :D :),,,,</i></font>';
ob_flush();
}
preg_match_all("#<div class=\"ruptext\">(.*?)</div>#",$html,$bal);
$rs=$bal[1][0];
$ps=$bal[1][1];
echo "<i><b><font color=orange>Q[$cques]. Success : Bal<font color=blue>-Rs $rs.$ps ||  </font>Answer:-</font><font color=blue>[".$da."]</font></i> ;</b>";
ob_flush();
flush();

if($cques<=30)
{
//echo "going to again<br>".$dataa."<br>";
goto qagain;
}
}
#end quiz

sms:

#region Final Balance Check
$dataa = "hToken=$id";
curl_setopt($ch, CURLOPT_URL,"http://u.laaptu.com/wallet.action?id=$id");

curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_POST, 1);

curl_setopt($ch, CURLOPT_POSTFIELDS,$dataa);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_REFERER, "http://u.laaptu.com/quiz.action?id=$id");
$html=curl_exec($ch);
$htmll = $html;
$htmll = preg_replace('/\s+/', ' ', trim($htmll));
$htmll = preg_replace('~[\r\n]+~', '', $htmll);
$htmll = preg_replace("/[\\n\\r]+/", "", $htmll);

preg_match("#<span class=\"totalboxgreen\">(.*?)</span>#",$htmll,$tbal);
$tbal=$tbal[1];
preg_match("#<div class=\"avaibalance\"> Available Balance :(.*?) </div>#",$html,$bal);
$bal=$bal[1];

echo "<div class=content2><font color=orange><b>TOTAL BALANCE : <font color=magenta>".$bal." <br><font color=green><br>Today balance : <font color=gray>Rs. ".$tbal."</b></font></font></font></font></div><br>";
#end region

function math_ocr_call($data,$cques)
{
$cque=$cques;
$st=$data;
$data = explode(";", $st);
$type = $data[0];
$data = explode(",", $data[1]);
$st=base64_decode($data[1]);
$im=imagecreatefromstring($st);
$name="not/".rand(1,500).".png";
imagepng($im,$name);
$string=mathocr($im);
return array($string,$name);
}
  
function fun_ocr_call($data,$cques)
{
$cque=$cques;
$st=$data;
$data = explode(";", $st);
$type = $data[0];
$data = explode(",", $data[1]);
$st=base64_decode($data[1]);
$im=imagecreatefromstring($st);

$string=funocr($im);
$name="img/".$string[0]."+".$string[1]."+".$string[2]."+".$string[3].".png";

imagepng($im,$name);
return array($string,$name,$img);
}  
  
?>




</form>