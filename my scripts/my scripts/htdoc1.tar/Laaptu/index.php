<html>
<head>
<center>
<div class="mainbox"><center><br><font color=green><font size=6pt>:::::Lap2 Site By Don :::::</font></center></div><br/>

<?php

##Plz Dont Remove This Command Line.##

if(!is_dir("img"))
{
mkdir("img");
}
if(!is_dir("coki"))
{
mkdir("coki");
}
?>
<center><form method="post" action="cap.php">
 Email Id : <input type="text" name="uid"><br>
 Password : <input type="password" name="pwd"><br>
<div>
<br><center><color=blue><font size=4pt>No Need To Enter Proxy</font>
</center><color>
</div> 
</br>
Proxy:Port <input type="proxy" name="proxy"><br>
<input type="submit" value="Start Earn">
</form>
<p><center><body bgcolor="black">


</center><div style="background:orange;padding:4px;color:red" align="center"><font size=4pt>ROCKS4M<font/></div> </body> </body>