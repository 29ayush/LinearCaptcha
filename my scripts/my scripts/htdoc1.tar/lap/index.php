<?php
echo '<center><font color=red>[LAAPTU FULL EARN]</font></center>';
if(!is_dir("img")){
mkdir("img");}
if(!file_exists('img/index.php')){
fopen('img/index.php','w');}
if(!is_dir("mycookie")){
mkdir("mycookie");}
if(!file_exists('mycookie/index.php')){
fopen('mycookie/index.php','w');}
?>
<center>
</head>
<body>

<body BGCOLOR="grey">
<div style="background:seagreen;padding:4px;color:darkgrey"align="center"> LAAPTU  ZONE </div>
<br>
<form method="post" action="submit.php">
<font face="Curlz MT"  size=5 color=lightred>Email:<br></font><input type="text" name="uid" placeholder="Email"><br>
<br>
<font face="Curlz MT"  size=5 color=lightred>Password:<br></font><input type="text" name="pwd" placeholder="Password"><br>
<br>

<br>
<font face="Curlz MT"  size=5 color=lightred>Proxy:<br></font><input type="text" name="pp" placeholder="Proxy"><br>
<br>
<input type="submit" value="PLAY QUIZ"></form></center>