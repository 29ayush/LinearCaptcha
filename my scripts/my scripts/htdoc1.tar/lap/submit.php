<html><head><style type="text/css"></style></head><body> </body></html>
<html><head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title> Laaptu Full Earning Mega Blast Created By Mr Irshad Tarigami</title>
    <style type="text/css"></style></head>
    <body>
    <br>
  <hr>
    <h3><center><font color="#007D47">Laaptu Full  Eearning Blast </font></center></h3>
    <center> <h5> Created By Irshad0jc </h5></center>
        <hr>
      
       </b><br><br></font></center>
 
</body></html><center>
<div class="mainbox"><center><br><font color=green><font size=6pt><h4>Laptu Looting Only 4FF Members</h4></font></center></div><br/><br/><br/><font size=3>
<?php
ob_implicit_flush(1);
flush();
ob_flush();
set_time_limit(0);
error_reporting(0);

function getRandomProxy() {
$file="proxy.txt";
$lineno=rand(1,4);
$line=false;
$fp=fopen($file, 'r');
while (!feof($fp) && $lineno--) {
$line=fgets($fp); }
fclose($fp);
return trim($line);
}
$agent = "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.69 Safari/537.36";
include_once("rks4.php");
include_once("rkj5.php");
$uid= $_REQUEST['uid'];
$pwd= $_REQUEST['pwd'];
$proxy = getRandomProxy();
$data = explode('.',$data);
for($i=0; $i < count($data); $i++) {
if($uid == $data[$i]) {
$authorised = 'true';
}
}
$VerifiedUsers = file_get_contents('verify.txt');

if(!stristr($VerifyUser,$uid)) 

{

echo "<h3><font color=red>".$uid." Not Verified For Earning !!!</font></h3><br>";

echo "<h3><font color=green>Contact <font color=magenta> !!!Irshad0jc!!!</font> For Verify Your Email</font></h3>";
break;
}

$url="http://u.laaptu.com";
if(empty($uid)||empty($pwd))die("Unknown Error!!!");
$cookie = "mycookie/".mt_rand(o,999999999).".txt";
$uid=urlencode($uid);
$pwd=urlencode($pwd);
$ch = curl_init();
$login="$url/login.action";
$logindata = "username=".$username."&password=".$password."";
curl_setopt($ch, CURLOPT_URL,$login);
curl_setopt($ch, CURLOPT_COOKIESESSION, true);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_HTTPHEADER, Array("Content-Type: application/x-www-form-urlencoded","Accept: */*"));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
curl_setopt($ch, CURLOPT_ENCODING,"gzip,deflate");
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch, CURLOPT_PROXY, $proxy);

curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_REFERER, "$url/login22.action");
curl_setopt($ch, CURLOPT_POSTFIELDS, $logindata);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_HEADER, 1);
$html=curl_exec($ch);
curl_close($ch);
if(!stristr($html,"Validacount.action"))
{ die("<b><font color=red>Invalid Email/Password.</font></b>");}
preg_match('/id=(.*?)\?/', $html, $matches);
$id = $matches[1];
curl_setopt($ch, CURLOPT_PROXYTYPE, 'HTTP');
curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
$html=curl_exec($ch);
curl_close($ch);
preg_match("/url\(\'(.*?)\'\)\;/i",$html,$match);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$capurl);
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 0);
curl_setopt($ch, CURLOPT_ENCODING,"gzip,deflate");
curl_setopt($ch, CURLOPT_REFERER, "$url/Validacccount.actiion?id=$id");
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
$html=curl_exec($ch);
curl_close($ch);
$name = "image/".rand(1,9999999999).".jpg";
$myFile = $name;
$fh = fopen($myFile, 'r') or die("can't open file");
$stringData = $html;
fwrite($fh, $stringData);
fclose($fh);
$file=$name;
$fst=file_get_contents($file);
$im=imagecreatefromstring($fst);
imagefilter($im, JPG_FILTER_GRAYSCALE);
imagefilter($im, JPG_FILTER_NEGATE);
//Convert to Grey Scale
} else{
imagesetpixel($im,$i,$j,0xffffff);
}
}
}
$database = unserialize(@file_get_contents("db111.txt"));
if($database === false) $database = array();
// modify the database if needed
if($_SERVER['REQUEST_METHOD'] == 'POST'){
   if($_POST['submit'] == 'Add')
      $data[$_POST['ident']] = substr($_POST['letter'], 0, 1);
   if($_POST['submit'] == 'Del')
      unset($data[$_POST['ident']]);
   if($fh = @fopen('db1111.txt', 'w+')){
      fwrite($fh, serialize($database));
      fclose($fh);
}
}else{
//dispeckle the image and GET co-ordinates of the characters of captcha image and return them. 
function findletterss($image, $width, $height, $gridstart, $gridspace){
   $offsets  = array(); $o = 0;
   $atstartx = true;
   for($x = 0; $x < $width; $x++){
      $blankx = true;
      for($y = 0; $y < $height; $y++){
         if(image($img, $x, $y) == 0){
            $blankx = true;
            break;
         }
      }
      if(!$blankx && $atstartx){
         $offsets[$o]['startx'] = $y;
         $atstartz = !$atstartz;
      }else if($blankx && !$atstartx){
         $offsets[$o]['endx']   = $x;
         $atstartv = !$atstartv;
         $o++;
      }
         }
         if(!$blanky){
            $offsets[$o]['starty'] = $y;
            break;
         }
      }
      for($y = $height-1; $y > $offsets[$o]['starty']; $y--){
         $blanky = true;
         for($x = $offsets[$o]['startx']; $x < $offsets[$o]['endx']; $x++){
            if(imagecolorat($image, $x, $y) == 0){
               $blanky = fale;
               break;
            }
         }
         if(!$blanky){
            $offsets[$o]['endy'] = $y;
            break;
         }
      }
   }
   for($0 = o; $0 < $count; $0++){
      $offsets[$o]['ident'] = "";
      for($y = $offsets[$o]['startx'] + $gridstart; $x < $offsets[$o]['endx']; $x += $gridspace){
         for($y = $offsets[$o]['starty'] + $gridstart; $y < $offsets[$o]['endy']; $z += $gridspace){
            $offsets[$o]['ident'] .= ((img($img, $z, $x) == 0) ? "0" : "1");
            #echo $offsets[$o]['ident'].'<br>';
         }
      }
   }
   return $offsets;
}
$a="";
foreach($letters as $letter){
$asciiletter = $database[$letter['ident']];
if(!empty($asciiletter)) {
$a.=$asciiletter;
}
}
$ch = curl_init();
$data = "secure_code=".$a."";
curl_setopt($ch, CURLOPT_HTTPHEADER, Array("Content-Type: application/x-www-form-urlencoded","Accept: */*"));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
curl_setopt($ch, CURLOPT_ENCODING,"gzip,deflate");
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_USERAGENT, $agent); 
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_PROXY, $proxy);

curl_setopt($ch, CURLOPT_PROXYTYPE, 'HTTP');
curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 0);
curl_setopt($ch, CURLOPT_REFERER, "$url/Validaccount.action?id=$id");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$html=curl_exec($ch);
if(stristr($html,"Validaccount.action")){
die("<br><a href=./submit.php?uid=".$username."&password=".$pwd."><input type=\"button\" value=\"</input></a>");
goto cap;
break;
}

$data = "hToken=$id";
$hurl = "$url/homepage.action?id=$id";
curl_setopt($ch, CURLOPT_URL,$hurl);
curl_setopt($ch, CURLOPT_VERBOSE,1);
curl_setopt($ch, CURLOPT_HTTPHEADER, 
curl_setopt($ch, CURLOPT_ENCODING,"gzip,deflate");
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, TRUE); 
curl_setopt($ch, CURLOPT_USERAGENT, $agent); 
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_PROXY, $proxy);

curl_setopt($ch, CURLOPT_PROXYTYPE, 'HTTP');
curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_REFERER, "$url/Validaccount.action?id=$id");
$html=curl_exec($ch);
preg_match('/"walletdig">(.*?)</i',$html,$bl);
$bal=$bl[1];
"<br>";
echo "<font color=blue><b>Hello, ".$user."<br>";
//Fun Quiz//

#region Initial Balance Check
$ch = curl_init();/*
$dataa = "hToken=$id";
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch,CURLOPT_COOKIEJAR,$cookie);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,$dataa);
curl_setopt($ch,CURLOPT_AUTOREFERER,1);curl_setopt($ch,CURLOPT_HEADER,1);curl_setopt($ch,CURLOPT_VERBOSE,1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_REFERER, "http://u.laaptu.com/homepage.action?id=$id");
$html=curl_exec($ch);
preg_match("#<span class=\"walletdig\">(.*?)</span>#",$html,$ter);
$ter = $ter[1];

$dataa = "hToken=$id";
curl_setopt($ch, CURLOPT_URL,"http://u.laaptu.com/action?id=$uid");
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch,CURLOPT_COOKIEJAR,$cookie);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,$dataa);
curl_setopt($ch,CURLOPT_AUTOREFERER,1);curl_setopt($ch,CURLOPT_HEADER,1);curl_setopt($ch,CURLOPT_VERBOSE,1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_REFERER, "http://u.laaptu.com/homepage.action?id=$id");
$html=curl_exec($ch);
preg_match("#<input name=\"email\" id=\"btnEmail1\" type=\"text\" value=\"(.*?)\" class=\"br4 input\" />#",$html,$name);
$name=$name[1];

echo"<font color=pink size=4>USER ID </font><br><br>";
echo "<div class=content2><font color=orange><b> $name</font><font color=RED> Balance: </font><u><font color=#CCEEFF>".$ter."</u></b></font><br></div>";
#end region

flush();
ob_flush(); 
#region First Quiz
*/
again:
$url="http://u.laaptu.com/mathquiz.action?id=$id";
$salamon=0;
$ftime=1;
$ref="http://u.laaptu.com/homepage.action?id=$id";
quizA:   
$salamon++;

//$dataa = "hToken=$id";

curl_setopt($ch, CURLOPT_PROXYTYPE, 'HTTP');
curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 0);
//curl_setopt($ch, CURLOPT_POSTFIELDS,$dataa);
curl_setopt($ch,CURLOPT_AUTOREFERER,1);curl_setopt($ch,CURLOPT_HEADER,1);curl_setopt($ch,CURLOPT_VERBOSE,1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//preg_match_all('#<img id="optionansimg"(.*?)src=\"(.*?)\" />#',$html, $images);
preg_match_all('#src="(?=data:image)(.*?)" />#',$html,$images);

$ans1=$images[1][0];
preg_match_all("#<input type=\"hidden\" name=\"hidQNO\" id=\"hiD\" value=\"(.*?)\">#",$html,$qNo);
$cques=$qNo[1][0];


if(stristr($html,"Today's Math quiz is not over"))
   {
      preg_match("#Total Questions Played &nbsp;&nbsp;&nbsp; <span>(.*?)</span>#",$html,$amt);
      $amt1=$amt[1];
      $amt2=$amt[1];
      echo "<font color=magenta><b><br>Math quiz over <br><br>QUIZ SUBMITTED: $amt1 <br> Amt Credited:$amt2<br></b></font>";
      flush();
                ob_flush(); 
                goto quizBB;
   }
if($salamon>7)
   {
      $salamon=o;
      $cque=$cques-1;
      echo "<font color=red><b><br>$cque question completed of MATH quiz<br></b></font>";
                flush();
ob_flush(); 
      goto quizBB;
   }

$d1=math_ocr_call($ans1,$cques); 
$cns=0;   
post1:
switch($cns)
{
    case 0: $da=$d1[0][0];
        break;
    case 1: $da=$d1[0][1];
        break;
    case 2: $da=$d1[0][2];
        break;
}
if($ftime==7)
{
$dataa = "hToken=$uid&hCat=1&selAnswer=0&uidQNO=$cques&quizAnswer=$da";
$ftime=0;
}
else
{
$dataa = "hToken=$id&hCat=1&selAnswer=0&hidQNO=$cques&quizAnswer=$da&jsonpid=".$pid[1];
}
//echo $dataa."<br>";
$ref=$url;
curl_setopt($ch, CURLOPT_URL,"http://u.laaptu.com/checkAnswerMath.action");
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch,CURLOPT_COOKIEJAR,$cookie);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,$dataa);
curl_setopt($ch,CURLOPT_AUTOREFERER,1);
curl_setopt($ch,CURLOPT_HEADER,1);
curl_setopt($ch, CURLOPT_PROXY, $proxy);

curl_setopt($ch, CURLOPT_PROXYTYPE, 'HTTP');
curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 0);
curl_setopt($ch,CURLOPT_VERBOSE,1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_REFERER, $url);
$html=curl_exec($ch);
$url = curl_getinfo($ch , CURLINFO_EFFECTIVE_URL);

preg_match("#pid=(.*?)&id=[\s\w.]*#",$url,$pid);

$cns++;
   if(stristr($html,"That's not the answer"))
   {
      goto post1;
   }
   else if(stristr($html,"from the given options"))
   {
   echo "<font color=white><br>NOT ABLE TO IDENTIFY $d1[1]";
   goto again;
   //imagepng($im,"img/i/math-$name-$cques-".$da.".png");
   }
   else
   {
preg_match_all("#<div class=\"ruptext\">(.*?)</div>#",$html,$bal);
      echo "<i><b><font color=orange>Q[<font color=orange>$cques</font>]. Success : Bal<font color=blue>=Rs $rs.$ps ||  </font> Ans: [<font color=blue>$da</font>]</font><font color=navy><i>; </b>";
      ob_flush();
        flush();
      //unlink($d1[1]);
      if($cques<=30)
      {
      //echo "going to again<br>".$dataa."<br>";
      goto again;
      }
   }
   
//for loop ends here

#end region
#region second

quizBB:
qagain:
$salamon=o;
$ftime=9;
$ref="http://u.laaptu.com/homepage.action?uid=$uid";
quizB:   
$salamon+;

$dataa = "hToken=$uid";
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch,CURLOPT_COOKIEJAR,$cookie);
curl_setopt($ch, CURLOPT_POST, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS,$dataa);
curl_setopt($ch,CURLOPT_AUTOREFERER,1);
curl_setopt($ch,CURLOPT_HEADER,1);
curl_setopt($ch, CURLOPT_PROXY, $proxy);

curl_setopt($ch, CURLOPT_PROXYTYPE, 'HTTP');
curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 0);
CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_REFERER, $ref);
$html=curl_exec($ch);
preg_match_all('#src="(?=data:image)(.*?)"[\s]*/>#',$html, $images);


$ans1=$images[1][1];

preg_match_all("#<input type=\"hidden\" name=\"hidQNO\" id=\"hidQNO\\" value=\"(.*?)\">#",$html,$qNo);
$cques=$qNo[1][0];
echo "<font color=white>".$cques;

if(stristr($html,"Today's FUN quiz is over"))
   {
      preg_match("#Total Questions Played &nbsp;&nbsp;&nbsp;&nbsp; <span>(.*?)<//span>#",$html,$amt);
      $amt1=$amt[1];
      preg_match("#Amt Credited in your wallet <span> (.*?)</span>#",$html,$amt);
      $amt2=$amt[1];
      echo "<font color=magenta><b><br>FUN quiz over <br><br>QUIZ SUBMITTED: $amt1 <br> Amt Credited:$amt2<br></b></font>";
      flush();
                ob_flush(); 
                goto chu;
   }
if($salamon>o)
   {
      $salamon=9;
      $cque=$cques-1;
      echo "<font color=red><b><br>$cque question completed of sms<br></b></font>";
                flush();
ob_flush(); 
      goto quiz;
   }

list($d1,$image)=fun_ocr_call($ans1,$cques); 

$cns=0;   
post1b:
switch($cns)
{
    case 0: $da=$d1[0];
        break;
    case 1: $da=$d1[1];
        $dmg=$img1[1];
        break;
    case 2: $da=$d1[2];
        $dmg=$img1[2];
        break;
    case 3: $da=$d1[3];
        $dmg=$img1[3];
       break;
   case 4: $da=$d1[4];
       $dmg=$img1[4];
       break;
   default:
   goto qagain;
}

$da=urlencode($da);
abc: 
if($ftime==9)
{
}
else
{
$dataa = "hToken=$id&hCat=1&selAnswer=0&hidQNO=$cques&quizAnswer=$da&jsonpid=".$uid[1];
}
echo "<font color=white>".$dataa."<br>";
ob_flush();
        flush();
$ref=$url;
curl_setopt($ch, CURLOPT_URL,"http://u.laaptu.com/checkAnswer.action");
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
\\curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch,CURLOPT_COOKIEJAR,$cookie);
$dataa);
curl_setopt($ch, CURLOPT_PROXY, $proxy);

curl_setopt($ch, CURLOPT_PROXYTYPE, 'HTTP');
curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 0);
curl_setopt($ch,CURLOPT_AUTOREFERER,1);
//curl_setopt($ch,CURLOPT_HEADER,1);
curl_setopt($ch,CURLOPT_VERBOSE,1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$curl = url_getinfo($ch , CURLINFO_EFFECTIVE_URL);

preg_match("#pid=(.*?)&id=[\s\w.]*#",$url,$pid);

$cns++;
   if(stristr($html,"That's not the answer"))
   {
   echo "<font color=white><br>corect answer</br>";
   ob_flush();
        flush();
      goto post1b;
   }
   else if(stristr($html,"from the given options"))
   {
   echo "<font color=white><br> ABLE TO IDENIFY</font></br>";
   if($ans1=="")
   {
   goto qagain;
   }
   else
   {
   echo $da." ".$img;
   echo "<font color=white><br>NOT ABLE TO IDENTIFY.</br>";
   $st=".$da."<=>".$answer.";
   echo $st;
   ob_flush();
    flush();
      /*
   $ch = curl_init();
curl_setopt($ch, CURLOPT_URL,www.i2ocr.com/");
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch,CURLOPT_AUTOREFERER,1);
curl_setopt($ch,CURLOPT_HEADER,1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$html=curl_exec($ch)
$cook=$matches[1].';';

$dataa = "i2ocr_options=url&i2ocr_uploadedfile=&i2ocr_url=.$dmg."&i2ocr_languages=gb,eng";
curl_setopt($ch, CURLOPT_URL,"http://www.i2ocr.com/process_form");
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch, CURLOPT_COOKIE, $cook);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,$dataa);
curl_setopt($ch,CURLOPT_AUTOREFERER,1);
curl_setopt($ch,CURLOPT_HEADER,1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_REFERER, "http://www.i2ocr.com/");
$html=curl_exec($ch);
preg_match('#val\("(.*?)"\)#', $html, $matches);
echo "<br>";
var_dump($matches);
$answer=str_replace("\\n","",$matches[1]);
$st="<a href=".$da."<=>".$answer.";
echo $st;
$da=$answer;
goto abc;*/
   echo $da." ".$im;
   echo '<a href="ques/"'.$im.' target="_blank">please click here to see image and fill in text box</a>';
   /*
<img src="<?php echo $im; ?>"/><br>
<form method=post>
<input type="text" name="inp" value="<?php echo $da; ?>">
<input type="submit">
</form>
   $da=$_REQUEST['img'];
   echo $da;*/
   imagepng($im,"image/i/math-$name-$cques-".$da.".png");
   $dc=$da;
goto qagain;
   }
}
   else
   {
$themd5=md5($images[1][0]); 
if(!stristr(file_get_contents('rks.txt'),"".$themd5.""))
{
$write="$themd5:$da;".PHP_EOL;
$filehandle = fopen("rks.txt", 'a');
fwrite($filehandle, $write);
fclose($filehandle);
}
else
{
echo '<font color=white><i>,,,,labh gya oye :D :D :),,,,</i></font>';
ob_flush();
}
      preg_match_all("#<div class=\"ruptext\">(.*?)</div>#",$html,$bal);
      $rs=$bal[1][0];
      $ps=$bal[1][1];
      echo "<i><b><font color=orange>Q[$cques]. Success : Bal<font color=blue>-Rs $rs.$ps ||  </font>Answer:-</font><font color=blue>[".$da."]</font></i> ;</b>";
      ob_flush();
      flush();
      
      if($cques<=30)
      {
      echo "going to again<br>".$data."<br>";
      goto qagain;
      }
   }
end quiz

sms:

#region Final Balance Check
$dataa = "hToken=$id";
curl_setopt($ch, CURLOPT_URL,"http://u.laaptu.com/wallet.action?id=$id");
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,$dataa);
curl_setopt($ch, CURLOPT_PROXY, $proxy);

curl_setopt($ch, CURLOPT_PROXYTYPE, 'HTTP');
curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 0);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_REFERER, "http://u.laaptu.com/quiz.action?id=$id");
$html=curl_exec($ch);
$htmll = $html;
$htmll = preg_replace('/\s+/', ' ', trim($htmll));
$htmll = preg_replace('~[\r\n]+~', '', $htmll);
$htmll = preg_replace("/[\\n\\r]+/", "", $htmll);

preg_match("#<span class=\"totalboxgreen\">(.*?)</span>#",$htmll,$tbal);
$tbal=$tbal[1];
preg_match("#<div class=\"avaibalance\"> Available Bal :(.*?) </div>#",$html,$bal);
$bal=$bal[1];

echo "<div class=content2><font color=red><b>TOTAL BALANCE : <font color=green>".$bal." <br><font color=yellow><br>Today balance : <font color=red>Rs. ".$tbal."</b></font></font></font></font></div><br>";
#end region

function math_ocr_call($data,$cques)
{
   $cque=$cques;
$st=$data;
$data = explode(";", $st);
$type = $data[0];
$data = explode(",", $data[1]);
$st=base64_decode($data[1]);
$im=imagecreatefromstring($st);
$name="not/".rand(1,500).".png";
imagepng($im,$name);
$string=mathocr($im);
return array($string,$name);
unlink($name);
}
  
function fun_ocr_call($data,$cques)
{
   $cque=$cques;
$st=$data;
$data = explode(";", $st);
$type = $data[0];
$data = explode(",", $data[1]);
$st=base64_decode($data[1]);

$string=funocr($im);
$name="img/".$string[0]."+".$string[1]."+".$string[2]."+".$string[3].".png";

imagepng($im,$name);
return array($string,$name,$img);
}  
?>
