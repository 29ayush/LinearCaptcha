<?php

function logincredits($html, $cookie, $agent, $login)
	{
	$url = "http://www.amulyam.in";
	$img = "" . $url . "/amulyamCo.do?cafp=dlc";
	if (stristr($html, "dlc.do"))
		{
		preg_match('<input type="hidden" name="lk" value="(.*?)"/>', $html, $captr);
		$lk = $captr[1];
		preg_match('<input type="hidden" name="lekv" value="(.*?)"/>', $html, $captr);
		$lekv = $captr[1];

                $ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $img);
		curl_setopt($ch, CURLOPT_USERAGENT, $agent);
		curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
		curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_BINARYTRANSFER, 1);
		curl_setopt($ch, CURLOPT_REFERER, $login);
		$abc = curl_exec($ch);

		$name = rand(9999999, 9999999999999999999);
		$path = 'img/' . $name . '.png';
		$fh = fopen($path, 'x');
		fwrite($fh, $abc);
		fclose($fh);
//		$text = img2txt($path);

       		curl_setopt($ch, CURLOPT_URL, $login);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_VERBOSE, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $pd);
		$html = curl_exec($ch);
		if (stristr($html, "Instant Rs.1 in Your Account") || stristr($html, "Martial Status"))
			{
			return "Daily Bonus Claimed.";
			}
		  else return "Some Error Occured While Claiming Captcha";
		}
        elseif (stristr($html, 'Verify your registered')) return "Can't Claim Login Bonus : MOBILE NO. NOT VERIFIED";
	else
		{
		return "Can't Claim Bonus : Daily Login Bonus For Today Has Already Been Claimed .";
		}
	}

?>

