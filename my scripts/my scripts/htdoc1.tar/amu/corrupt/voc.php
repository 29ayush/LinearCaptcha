<?php
$z="%2B";
$z=urldecode($z);
$voc = "$url/vocabulary.do";
curl_setopt( $ch, CURLOPT_URL, $voc);
curl_setopt( $ch, CURLOPT_USERAGENT, $agent );
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//curl_setopt($ch,CURLOPT_POSTFIELDS,$pd);
$html=curl_exec($ch);
//echo $html;
if(stristr($html,"You are eligible to get 50"))
{
preg_match_all('/bid=(.*?)" target="_blank"/',$html,$captr);
   $ad = $captr[1];
$url1="http://www.amulyam.in/amulyamCo.do?cafp=goToBanner&bid=$ad[0]";
$url2="http://www.amulyam.in/amulyamCo.do?cafp=goToBanner&bid=$ad[1]";
//echo "<hr>TRIVIA COMPLETED.<hr><hr>";
curl_setopt( $ch, CURLOPT_URL, $url1);
curl_setopt( $ch, CURLOPT_USERAGENT, $agent );
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//curl_setopt($ch,CURLOPT_POSTFIELDS,$pd);
$html=curl_exec($ch);
//echo $html;
curl_setopt( $ch, CURLOPT_URL, $url2);
curl_setopt( $ch, CURLOPT_USERAGENT, $agent );
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//curl_setopt($ch,CURLOPT_POSTFIELDS,$pd);
$html=curl_exec($ch);
curl_setopt( $ch, CURLOPT_URL, "$url/amulyamCo.do?cafp=claimVocabulary");
curl_setopt( $ch, CURLOPT_USERAGENT, $agent );
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, "");
$html=curl_exec($ch);
//echo $html;
if(stristr($html,"has been credited"))
{
echo "<hr><font color='green'>Woohoo!!! captcha claimed.<br>Refresh the page one time to see latest balance.</font><hr>";
}
else
{
echo "<hr><font color='red'>Unable to claim captcha.</font><hr>";
}
}
else
if(stristr($html,"You have played"))
{
echo "<hr><font color='green'>Today's Vocublary Game Completed.</font><hr><hr><hr><hr><p>";
include "tri.php";
}
else
{
for($start=1;$start<=40;$start++)
{
$voc = "$url/vocabulary.do";
curl_setopt( $ch, CURLOPT_URL, $voc);
curl_setopt( $ch, CURLOPT_USERAGENT, $agent );
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//curl_setopt($ch,CURLOPT_POSTFIELDS,$pd);
$html=curl_exec($ch);
preg_match('/<h3 style=" text-align: left; margin-top: 10px;" >(.*?)</',$html,$captr);
   $wrd = $captr[1];
preg_match('<input  type="hidden" name="cp" value="(.*?)"/>',$html,$captr);
   $que = $captr[1];
$pd = "word=$wrd&cp=$que";
//echo "$pd<hr>";
curl_setopt( $ch, CURLOPT_URL, "$url/showLWord.do");
curl_setopt( $ch, CURLOPT_USERAGENT, $agent );
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$pd);
$html=curl_exec($ch);
if(stristr($html,"choose the above number in below options"))
{
$img="http://www.amulyam.in/vocabularyLinkCaptcha.do";
   curl_setopt($ch, CURLOPT_URL, $img);
               curl_setopt( $ch, CURLOPT_USERAGENT, $agent );
               curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
                  curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
               curl_setopt($ch, CURLOPT_BINARYTRANSFER,1);      
               $abc=curl_exec($ch);
      $path='img.png';
$fh = fopen("$path","a+");
fwrite($fh, $abc);
fclose($fh);
include "c.php";
echo "<font color='brown'>You are in question no. $que of vocublary.<hr></font>";
echo "<hr><font color='skyblue'>Answer:$wrd<hr></font>";
include "cap.php";


//echo '<center><font color="red">Type captcha </font><br><img src="img.png"><br><form action="cap.php" method="get"><input type="text" name="cap" value="'.$bps.'"><input type="hidden" name="cookie" value="'.$cookie.'"><input type="hidden" name="que" value="'.$que.'"><input type="hidden" name="uid" value="'.$mob.'"><input type="hidden" name="pwd" value="'.$pwd.'">      <br><input type="submit" value="Submit"><hr><hr><hr><hr>';
$dir="img.png";
 
      unlink($dir);  

//goto voc;
}
else
if(stristr($html,"Word 0 of 14"))
{ 
echo "<hr>VOCUBLARY COMPLETED<hr>";
}
else
{

}
}
}
?>