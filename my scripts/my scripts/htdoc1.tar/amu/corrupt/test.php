<?php
$html=file_get_contents("log2.txt");
preg_match('<input type="hidden" name="lk" value="(.*?)"/>',$html,$captr);
$lk = $captr[1];
echo "lk=$lk<hr>";

preg_match('<input type="hidden" name="lekv" value="(.*?)"/>',$html,$captr);
$lekv = $captr[1];
echo "lekv=$lekv<hr>";
?>