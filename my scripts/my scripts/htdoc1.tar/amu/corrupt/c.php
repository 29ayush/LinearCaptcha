<?php
//$cookie= tempnam("/tmp", "CURLCOOKIE");
//$file = "cap/img2.png";
//$agent = "Mozilla/5.0 (Windows; U; Windows NT 5.0; en-US; rv:1.7.12) Gecko/20050915 Firefox/1.0.7";
//$ch = curl_init();
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, array("outputencoding"=>"utf-8","userfile"=>"@img.png"));
curl_setopt($ch, CURLOPT_URL, 'http://maggie.ocrgrid.org/cgi-bin/weocr/nhocr.cgi');
					curl_setopt( $ch, CURLOPT_USERAGENT, $agent );
				curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
//curl_setopt($ch, CURLOPT_POSTFIELDS, $pd);
$html = curl_exec($ch);
//echo $html;
$output = preg_replace('/[^0-9]/','', $html);
//echo $output;
preg_match('/8444(.*?)14/',$output,$captr);
$bps = $captr[1];
//echo $bps;
?>