<?php
ob_implicit_flush(1);
flush();
ob_flush();
set_time_limit(0);
error_reporting(0);
$agent="Mozilla/5.0 (Windows NT 6.2; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0"; 



//intial:
for($start=1;$start<=500;$start++)
{
$tri = "http://www.amulyam.in/playTrivia.do";
curl_setopt( $ch, CURLOPT_URL, $tri);
curl_setopt( $ch, CURLOPT_USERAGENT, $agent );
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//curl_setopt($ch,CURLOPT_POSTFIELDS,$pd);
$html=curl_exec($ch);
preg_match('<input type="hidden" name="cp" value="(.*?)"/>',$html,$captr);
   $que = $captr[1];
$pd = "cp=$que&answer=TRUE";
curl_setopt( $ch, CURLOPT_URL, "$url/checkTrivia.do");
curl_setopt( $ch, CURLOPT_USERAGENT, $agent );
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$pd);
$html=curl_exec($ch);
if(stristr($html,"Captcha"))
{
cs:
$img="$url/triviaCaptcha.do";
	curl_setopt($ch, CURLOPT_URL, $img);
					curl_setopt( $ch, CURLOPT_USERAGENT, $agent );
					curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
						curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
					curl_setopt($ch, CURLOPT_BINARYTRANSFER,1);		
					$abc=curl_exec($ch);
	$name=rand(9999999, 9999999999999999999);
					$path='imgg.png';
$z=urldecode('%2B');
		$fh = fopen("imgg.png","a$z");
					fwrite($fh, $abc);
					fclose($fh);
include "cc.php";
//sleep(2);
//echo '<font color="brown">Q no. '.$que.' </font>';
//sleep(2);
//echo "<font color=skyblue> Trying to submit captcha </font><hr>";
$ur = "http://www.amulyam.in/checkTriviaCaptcha.do";
$pd = "captcha=$bps&cp=$que";
//echo"$pd";
curl_setopt($ch, CURLOPT_URL, $ur);
					curl_setopt( $ch, CURLOPT_USERAGENT, $agent );
				curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
//curl_setopt($ch, CURLOPT_REFERER, "http://www.amulyam.in/vocabularyLinkCaptcha.do");
curl_setopt($ch,CURLOPT_POSTFIELDS,$pd);
$one=curl_exec($ch);
//echo $one;
if(stristr($one,"Question 1 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}
if(stristr($one,"Question 2 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}
if(stristr($one,"Question 3 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}
if(stristr($one,"Question 4 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}
if(stristr($one,"Question 5 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}
if(stristr($one,"Question 6 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}
if(stristr($one,"Question 7 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}
if(stristr($one,"Question 8 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}if(stristr($one,"Question 9 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}
if(stristr($one,"Question 10 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}if(stristr($one,"Question 11 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}
if(stristr($one,"Question 12 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}
if(stristr($one,"Question 13 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}if(stristr($one,"Question 14 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}if(stristr($one,"Question 15 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}if(stristr($one,"Question 16 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}if(stristr($one,"Question 17 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}if(stristr($one,"Question 18 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}if(stristr($one,"Question 19 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}if(stristr($one,"Question 20 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}if(stristr($one,"Question 21 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}if(stristr($one,"Question 22 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}if(stristr($one,"Question 23 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}if(stristr($one,"Question 24 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}
if(stristr($one,"Question 25 of 25 "))
{
echo '<font color="brown">Q no. '.$que.' </font><br>';
//goto cs;
}
if(stristr($one,"playTrivia.do"))
{
echo '<font color="green">Completed';
//goto cs;
}

if(stristr($one,"You have selected the wrong number"))
{
//echo '<font color="brown">Q no. '.$que.' </font>';
//goto cs;
}
else
{
//echo "<font color=green>Right captcha</font><hr>";
}
if($que==25)
{
echo '<font color="brown">Q no. '.$que.' </font>';
//goto final;
}
//final:
$tri = "http://www.amulyam.in/playTrivia.do";
curl_setopt( $ch, CURLOPT_URL, $tri);
curl_setopt( $ch, CURLOPT_USERAGENT, $agent );
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//curl_setopt($ch,CURLOPT_POSTFIELDS,$pd);
$html=curl_exec($ch);
//echo $html;
if(stristr($html,"Good Job!!"))
//goto  final;
{
preg_match_all('/bid=(.*?)" target="_blank"/',$html,$captr);
   $ad = $captr[1];
   

$url1="http://www.amulyam.in/amulyamCo.do?cafp=goToBanner&bid=$ad[0]";
$url2="http://www.amulyam.in/amulyamCo.do?cafp=goToBanner&bid=$ad[1]";
//echo "<hr>TRIVIA COMPLETED.<hr><hr>";
curl_setopt( $ch, CURLOPT_URL, $url1);
curl_setopt( $ch, CURLOPT_USERAGENT, $agent );
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//curl_setopt($ch,CURLOPT_POSTFIELDS,$pd);
$html=curl_exec($ch);
//echo $html;
curl_setopt( $ch, CURLOPT_URL, $url2);
curl_setopt( $ch, CURLOPT_USERAGENT, $agent );
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//curl_setopt($ch,CURLOPT_POSTFIELDS,$pd);
$html=curl_exec($ch);
curl_setopt( $ch, CURLOPT_URL, "$url/amulyamCo.do?cafp=claimTrivia");
curl_setopt( $ch, CURLOPT_USERAGENT, $agent );
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, "");
$html=curl_exec($ch);
//echo $html;
if(stristr($html,"has been added in your"))
{
echo "<hr><font color='green'>Woohoo!!! Game Completed :).</font><hr>";
break;
}
else
{
echo "<hr><font color='red'>Unable to claim captcha.</font><hr>";
}
}
else
if(stristr($html,"You have played"))
{
echo "<hr><hr><hr><hr><hr><hr><font color='green'>Today's Trivia Game Completed.</font><hr>";
break;
}

//echo $html;
//include "capt.php";
//echo '<center><font color="red">Type captcha </font><br><img src="'.$path.'"><br><form action="capt.php" method="get"><center><input type="text" name="cap" value="'.$bps.'"><input type="hidden" name="cookie" value="'.$cookie.'"><input type="hidden" name="que" value="'.$que.'"><input type="hidden" name="uid" value="'.$mob.'">     <input type="hidden" name="pwd" value="'.$pwd.'"> <br><input type="submit" value="Submit"><hr><hr><hr><hr></form>';
unlink('imgg.png');
//echo $html;
}
else
if(stristr($html,"Word 0 of 15"))
{ 
//echo $html;
}
else
{
//echo"word submitted";
//echo $html;
}
}


?>