<?php
echo "<font color=skyblue> Trying to submit captcha </font><hr>";
//$que = $_REQUEST['que'];
//$cookie = $_REQUEST['cookie'];
//$uid = $_REQUEST['uid'];
//$pwd = $_REQUEST['pwd'];
//$lekv = $_REQUEST['lekv'];
//$ap = $_REQUEST['cap'];
//$cap = strtoupper($ap);
$ur = "http://www.amulyam.in/checkTriviaCaptcha.do";
$pd = "captcha=$bps&cp=$que";
//echo $pd;
//$agent = "Mozilla/5.0 (Windows; U; Windows NT 5.0; en-US; rv:1.7.12) Gecko/20050915 Firefox/1.0.7";
//$ch = curl_init();
//$url="http://www.amulyam.in";
curl_setopt($ch, CURLOPT_URL, $ur);
					curl_setopt( $ch, CURLOPT_USERAGENT, $agent );
				curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
//curl_setopt($ch, CURLOPT_REFERER, "http://www.amulyam.in/vocabularyLinkCaptcha.do");
curl_setopt($ch,CURLOPT_POSTFIELDS,$pd);
$one=curl_exec($ch);
//echo $one;
if(stristr($one,"You have selected the wrong number"))
{
echo "<font color=red>wrong captcha</font><hr>";
goto cs;
}
else
{
echo "<font color=green>Right captcha</font><hr>";
}
?>