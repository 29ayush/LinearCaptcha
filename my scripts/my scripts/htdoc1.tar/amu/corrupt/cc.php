<?php
$rl=array("http://jimbocho.ocrgrid.org/cgi-bin/weocr/submit_ocrad.cgi","http://michelle.ocrgrid.org/cgi-bin/weocr/submit_e1.cgi");
$i=rand(0,2);
$crl=$rl[$i];
$crl="http://maggie.ocrgrid.org/cgi-bin/weocr/nhocr.cgi";
//echo $crl;
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, array("outputencoding"=>"utf-8","userfile"=>"@imgg.png"));
curl_setopt($ch, CURLOPT_URL, $crl);
					curl_setopt( $ch, CURLOPT_USERAGENT, $agent );
				curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
//curl_setopt($ch, CURLOPT_POSTFIELDS, $pd);
$html = curl_exec($ch);
//echo $html;
$output = preg_replace('/[^A-Z0-9]/','', $html);
//echo $output;
preg_match('/8444R(.*?)D14/',$output,$captr);
$bps = $captr[1];
//echo $bps;
?>