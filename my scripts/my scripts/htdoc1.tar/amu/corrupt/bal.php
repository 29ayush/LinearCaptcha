<?php
curl_setopt( $ch, CURLOPT_URL, "http://www.amulyam.in/displayMyWallet.do");
curl_setopt( $ch, CURLOPT_USERAGENT, $agent );
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_HEADER, 1);
//curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//curl_setopt($ch,CURLOPT_POSTFIELDS,$pd);
$html = curl_exec($ch);
preg_match('/<span class="balance">Rs.(.*?)</',$html,$captr);
   $bal = $captr[1];
echo "<hr><font size=3pt><font color='blue'>Current balance :- </font><font color='seagreen'> Rs.$bal <a href='amu.php?uid=$mob&pwd=$pwd'>[Refresh]</a></font></font><hr><hr>";
$abc = "<font color='red'> $mob </font><font color='blue'> $pwd </font><font color='green'> Rs.$bal </font><br>";
$fh = fopen("bal/cig/$uid.php","a+");
					fwrite($fh, $abc);
					fclose($fh);
?>