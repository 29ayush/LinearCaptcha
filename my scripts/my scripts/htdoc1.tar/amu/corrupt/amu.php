<html><head><style type="text/css"></style></head><body> </body></html>
<html><head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        
    <style type="text/css"></style></head>
    <body>
    <br>
  <hr>
    <h3><center><font color="#007D47">Amulyam Blast  </font></center></h3>
    <center> <h5> DAMAKAAA </h5></center>
        <hr>
      
       </b></font></center>
 
</body></html><center>

<body BGCOLOR="white">
<div style="background:seagreen;padding:4px;color:darkgrey"align="center"> Earning ZONE</div>
<?php
ob_implicit_flush(1);
flush();
ob_flush();
set_time_limit(0);
error_reporting(0);
$url = "http://www.amulyam.in";
$home="$url/home.do";
$log="$url/login.do";
$mob=isset($_REQUEST['uid'])?trim($_REQUEST['uid']):""; 
$pwd=isset($_REQUEST['pwd'])?trim($_REQUEST['pwd']):"";



$cookie= tempnam("/tmp", "CURLCOOKIE");

$agent="Mozilla/5.0 (Windows NT 6.2; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0"; 

$ch = curl_init();
curl_setopt( $ch, CURLOPT_URL, $home);
curl_setopt( $ch, CURLOPT_USERAGENT, $agent );
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$html = curl_exec($ch);

preg_match('<input type="hidden" name="org.apache.struts.taglib.html.TOKEN" value="(.*?)">',$html,$captr);

$tok = $captr[1];
$pd="org.apache.struts.taglib.html.TOKEN=$tok&mobile=$mob&password=$pwd&remember=1";


//echo "$pd<hr>";
curl_setopt( $ch, CURLOPT_URL, $log);
curl_setopt( $ch, CURLOPT_USERAGENT, $agent );
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$pd);
$html = curl_exec($ch);

if(stristr($html,"Forgot Password"))
{
echo "<font size=10pt><font color='red'>wrongUSER&PASS</font></font>";
}
else
{
echo "<font size=6pt><font color='green'>Login Successfull<hr><hr><hr></font></font>";
}


if(stristr($html,"dlc.do"))
{

preg_match('<input type="hidden" name="lk" value="(.*?)"/>',$html,$captr);
$lk = $captr[1];
echo "lk=$lk<hr>";

preg_match('<input type="hidden" name="lekv" value="(.*?)"/>',$html,$captr);
$lekv = $captr[1];
echo "lekv=$lekv<hr>";

echo "<center><font size=6pt>TYPE LOGIN CAPTCHA<br></font>";

$url = "http://www.amulyam.in";
$img="".$url."/amulyamCo.do?cafp=dlc";

curl_setopt($ch, CURLOPT_URL, $img);
curl_setopt( $ch, CURLOPT_USERAGENT, $agent );
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_BINARYTRANSFER,1);      
curl_setopt( $ch, CURLOPT_REFERER, $log );
$abc=curl_exec($ch);

$name=rand(9999999, 9999999999999999999);
$path='img/'.$name.'.png';
$fh = fopen($path, 'x');
fwrite($fh, $abc);
fclose($fh);

echo '<center><img src="'.$path.'"><br>
<form action="dlc.php" method="get">
<input type="text" name="cap">
<input type="hidden" name="cookie" value="'.$cookie.'">
<input type="hidden" name="lk" value='.$lk.'> 
<input type="hidden" name="lekv" value= '.$lekv.' >     
<br><input type="submit" value="Submit"><hr><hr><hr><hr>';


}

else
{

include "bal.php";


include "tri.php";
}
?>