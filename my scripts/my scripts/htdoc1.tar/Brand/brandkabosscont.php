<?php

error_reporting(0);
ob_implicit_flush(1);
$url = "http://ultoo.com";
$bal="$url/mywallet.php?zxcoiesesscd=";
$secure = "$url/secure.php";
$brandstart = "$url/brands.php";
$brandques = "$url/brands_ques.php";
$login = "$url/mywallet.php?zxcoiesesscd=";
$brandend = "$url/brands_result.php";
$brandmid = "$url/brands_graph.php";
$agent = "Opera/9.80 (J2ME/MIDP; Opera Mini/4.5.33634/32.1440; U; en) Presto/2.8.119 Version/11.10";
$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
$headers[] = 'Connection: Keep-Alive';
$headers[] = 'Content-type: application/x-www-form-urlencoded;charset=UTF-8';
$headers[] = 'Accept-Language: en-us,en;q=0.8';
$headers[] = 'Accept-Encoding gzip,deflate';
$headers[] = 'Keep-Alive: 300';
$headers[] = 'Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7';
$headers[] = 'Cache-Control: max-age=0';
$captr = $_REQUEST['captr'];
$cookie = $_REQUEST['cookie'];
$username = trim($_REQUEST['username']);
$cap = $_REQUEST['cap'];
$playno=$_REQUEST['playno'];
$count =isset($_REQUEST['count'])?$_REQUEST['count'] : $playno+1;

echo "<h2><font color=green>Logged In : Successfully</h2><br/>";
echo "<p>Welcome User : $username</p><hr>";

$ch = curl_init();
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

BrandkabossStart:

	require_once 'ultoogamefunctions.php';

	curl_setopt($ch, CURLOPT_URL, $brandstart);
	curl_setopt($ch, CURLOPT_POST, 0);
	curl_setopt($ch, CURLOPT_REFERER, $brandstart);

	//  Remaining Curl OPTIONS DECLARED ABOVE

	$brandstarthtml = curl_exec($ch);

	for ($i = 0; $i < 10; $i++)
		{

		// Getting Question Page

		curl_setopt($ch, CURLOPT_URL, $brandques);
		curl_setopt($ch, CURLOPT_POST, 0);

		// If First QUestion referrer = start page else graph page

		if ($i == 0) curl_setopt($ch, CURLOPT_REFERER, $brandstart);
		  else curl_setopt($ch, CURLOPT_REFERER, $brandmid);
		$getqueshtml = curl_exec($ch);

		$data = getbrandgamepostdata($getqueshtml);

		curl_setopt($ch, CURLOPT_URL, $brandques);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLOPT_REFERER, $brandques);
		$quessubmithtml = curl_exec($ch);

		$qno = $i + 1;
		if (stristr($quessubmithtml, "Result No.$qno"))
			{
			echo "<font color=seagreen>| $qno. </font><font color=Crimson>Answer Submitted|</font>,";
			flush();
			ob_flush();
			}
		  else
			{
			file_put_contents("Brandkapart1error$i.txt", $getqueshtml);
			file_put_contents("Brandkapart2error$i.txt", $quessubmithtml);
			die("|$qno error|");
			flush();
			ob_flush();
			}
		}

        curl_setopt($ch, CURLOPT_URL, $bal);
	curl_setopt($ch, CURLOPT_POST, 0);
	curl_setopt($ch, CURLOPT_REFERRER, $brandend);
        $balhtml= curl_exec($ch);

        preg_match("/<p>Rs<\/p>\s*<h1>(.*)<\/h1>/",$balhtml,$matches);
        $rs= $matches[1];
        preg_match("/<p>Paisa<\/p>\s*<h1>(.*)<\/h1>/",$balhtml,$matches);
        $ps= $matches[1];
        echo "<hr><span style=\"text-align:center;  display:block;\">Completed The Brand Ka Boss Quiz $count times.".str_repeat('&nbsp;', 10).":1: &nbsp;&nbsp; Your Balance: Rs. $rs.$ps  &nbsp;&nbsp; :1:</span><hr>";



        $count++;
        sleep(3);
        if($count % $playno != 1 ) goto BrandkabossStart;
echo $_SERVER['SERVER_ADDR'];
$url=addslashes("http://localhost:9543/Brand/brandkabosscont.php?username=$username&cookie=$cookie&count=$count&playno=$playno");
echo "Brands Complete. count = $count Go Check Your Earnings<script>document.location.href=\"$url\";</script>";
?>