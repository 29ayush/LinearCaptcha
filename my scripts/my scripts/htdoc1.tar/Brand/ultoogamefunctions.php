<?php
function getbrandgamepostdata($html)
	{
	preg_match('/<input type=\"radio\" value=\"(.*)\" name=\"option\[\]\" class=\"hidden\" id=\"category_5\">/', $html, $matches);
	$value = urlencode($matches[1]);
	$value = str_replace("%20", "+", $value);
	preg_match("/el.name='(.*)'/i", $html, $matches);
	$name = $matches[1];
	preg_match("/process\('(.*)'/i", $html, $matches);
        $val=$matches[1];
        
        preg_match_all("/val = val\.(.*)\((.*)\)/i", $html, $matches);
        $count = count($matches[1]);

        for($i=0; $i<$count;$i++)
        {

        $func=$matches[1][$i];       
        $index = $matches[2][$i];
	$index = explode(',', $index);
	if ($index[1] == "") $index[1] = strlen($val);
        if($index[0]<0) $index[0] = strlen($val) + $index[0] + 1;
        if($index[1]<0) $index[1] = strlen($val) + $index[1];
        
        if ($func == "substring" || $func == "slice") $val = substr($val, $index[0], $index[1] - $index[0]);
	elseif ($func == "substr") $val = substr($val, $index[0], $index[1]);
 	elseif ($func == "charAt") $val = $val[$index[0]];
        elseif ($func == "toLowerCase") $val = strtolower($val);
        elseif ($func == "toUpperCase") $val = strtoupper($val);
         
        }

        $submit = $name."=".$val;

	$url = "fbshare=0&option[]=$value&$submit&button=Lock Your Choice";
	return $url;
	}
?>