<?php
error_reporting(0);
ob_implicit_flush(1);
$url = "http://ultoo.com";
$bal="$url/mywallet.php?zxcoiesesscd=";
$secure = "$url/secure.php";
$brandstart = "$url/brands.php";
$brandques = "$url/brands_ques.php";
$login = "$url/mywallet.php?zxcoiesesscd=";
$brandend = "$url/brands_result.php";
$brandmid = "$url/brands_graph.php";
$agent = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:30.0) Gecko/20100101 Firefox/30.0";

$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8';
$headers[] = 'Accept-Language: en-us,en;q=0.5';
$headers[] = 'HOST: ultoo.com';
// $headers[] = 'Accept-Encoding: gzip,deflate';
$headers[] = 'Connection: Keep-Alive';


$captr = $_REQUEST['captr'];
$cookie = $_REQUEST['cookie'];
$username = trim($_REQUEST['username']);
$cap = $_REQUEST['cap'];
$playno=5;
$count=1;

// Start Submitting Captcha

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $secure);
curl_setopt($ch, CURLOPT_USERAGENT, $agent);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$cap_data = $captr . "=nlp&captcha=$cap";
curl_setopt($ch, CURLOPT_POSTFIELDS, $cap_data);
$html = curl_exec($ch);

if (stristr($html, "box do not match"))
	{
	die("<h3><tt><font color=red>------------ You Have Entered Wrong Captcha. --------</font></h3>");
	}

if (stristr($html, "mywallet"))
	{
	echo "<h2><font color=green>Logged In : Successfully</h2><br/>";
	echo "<p>Welcome User : $username</p>";
	flush();
	ob_flush();
	sleep(3);
	}
  else echo $html;

// Captcha Ended	Brand Ka Boss Start

BrandkabossStart:

	require_once 'ultoogamefunctions.php';

	curl_setopt($ch, CURLOPT_URL, $brandstart);
	curl_setopt($ch, CURLOPT_POST, 0);
	curl_setopt($ch, CURLOPT_REFERER, $brandstart);

	//  Remaining Curl OPTIONS DECLARED ABOVE

	$brandstarthtml = curl_exec($ch);

	for ($i = 0; $i < 10; $i++)
		{

		// Getting Question Page

		curl_setopt($ch, CURLOPT_URL, $brandques);
		curl_setopt($ch, CURLOPT_POST, 0);

		// If First QUestion referrer = start page else graph page

		if ($i == 0) curl_setopt($ch, CURLOPT_REFERER, $brandstart);
		  else curl_setopt($ch, CURLOPT_REFERER, $brandmid);
		$getqueshtml = curl_exec($ch);
                print_r(curl_error($ch));
                echo "<br/>";

		$data = getbrandgamepostdata($getqueshtml);
                echo $data;                

		curl_setopt($ch, CURLOPT_URL, $brandques);
		curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLOPT_REFERER, $brandques);
		$quessubmithtml = curl_exec($ch);
var_dump(curl_getinfo($ch));
                echo "<br/>";

		curl_setopt($ch, CURLOPT_URL, $brandmid);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_POST, 0);
		curl_setopt($ch, CURLOPT_REFERER, $brandques);
		$quesgraphhtml = curl_exec($ch);
                print_r(curl_error($ch));
echo "<br/>";
file_put_contents("Brandkapart1error$i.txt", $getqueshtml);
			file_put_contents("Brandkapart2error$i.txt", $quessubmithtml);
                        file_put_contents("Brandkapart3error$i.txt", $quesgraphhtml);
		$qno = $i + 1;
		if (stristr($quesgraphhtml, "Result No.$qno"))
			{
			echo "<font color=seagreen>| $qno. </font><font color=Crimson>Answer Submitted|</font>,";
			flush();
			ob_flush();
			}
		  else
			{
			file_put_contents("Brandkapart1error$i.txt", $getqueshtml);
			file_put_contents("Brandkapart2error$i.txt", $quessubmithtml);
                        file_put_contents("Brandkapart3error$i.txt", $quesgraphhtml);
			die( "|$qno error|");
			flush();
			ob_flush();
			}
		}
        curl_setopt($ch, CURLOPT_URL, $bal);
	curl_setopt($ch, CURLOPT_POST, 0);
	curl_setopt($ch, CURLOPT_REFERRER, $brandend);
        $balhtml= curl_exec($ch);

        preg_match("/<p>Rs<\/p>\s*<h1>(.*)<\/h1>/",$balhtml,$matches);
        $rs= $matches[1];
        preg_match("/<p>Paisa<\/p>\s*<h1>(.*)<\/h1>/",$balhtml,$matches);
        $ps= $matches[1];

        echo "<hr><span style=\"text-align:center;  display:block;\">Completed The Brand Ka Boss Quiz $count times.".str_repeat('&nbsp;', 10).":1: &nbsp;&nbsp; Your Balance: Rs. $rs.$ps &nbsp;&nbsp; :1:</span><hr>";



        $count++;
        sleep(3);
        if($count % $playno != 1 ) goto BrandkabossStart;

	echo "Brands Complete. Go Check Your Earnings<br/>Cookie: $cookie";
        echo"<br/> Url : http://localhost:9543/Brand/brandkabosscont.php?username=$username&cookie=$cookie&playno=$playno";
?>