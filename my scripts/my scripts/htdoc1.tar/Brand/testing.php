<?php
require_once "ultoogamefunctions.php";
$html= file_get_contents("log2.txt");
echo getbrandgamepostdata($html);
echo "Script";
?>
