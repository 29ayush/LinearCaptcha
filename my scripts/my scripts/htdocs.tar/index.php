<font face="Trebuchet MS"><html>
<align="center"><head>
<center><title>Amulyam Full Earning By: AllTechInOne.com </title>

<br/>
<link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
<align="center"><div class='header' style="font-size:22px;">AMULYAM FULL EARNING </div>

<div class='title'><center> <a href="https://www.facebook.com/alltechinonefree" target="_blank" title="Like Our Facebook Page">Like Our Facebook page !!</a></center></div>
<div class="title2"> Enter Login Details </div>
<div class="mainbox"><center><br><font color=green><font size=3pt>PLAY ALL(VOCABULARY + TRIVIA + LOGIN-BONUS)</font></center></div>

<p align="center"><b style="color:"><script src="http://greentooth.xtgem.com/j/time.js"></script></b></p> 

<center>
<form action="trivia.php" method="post">

Username :<br> <input type="text" id="mobile" name="mobile"><br>
Password :<br> <input type="text" id="mobile" name="password"><br><br>
<br>
 <input type=submit name=submit value=StartEarn>
</form>
</center>


</div>

<br/>
<div id="footer_bg">
<div class="footer" align="center">&copy; <a href="http://www.alltechinone.com/" target="_blank" title="Visit Our Site">All Tech In One</a></div>