<?php
error_reporting(0);
function img2txt($imgpath)
	{

        $url = "sample.php";       
        $datapage1="image=/var/www/html/".$imgpath;
        $ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $datapage1);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$exec= curl_exec($ch);
        return $exec;

	}



$url=$_REQUEST['url'];
$ch=curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_BINARYTRANSFER, 1);
$abc = curl_exec($ch);
$name1 = "img".rand(0, 999999999);
$path = 'img/'.$name1.'.png';
unlink($path);
$fh = fopen($path, 'x');
fwrite($fh, $abc);
fclose($fh);
echo img2txt($path);
?>